
import { NextResponse } from 'next/server';
import type { Invoice } from '@/types';
import fs from 'fs/promises';
import path from 'path';
import { verifyOtp } from '@/lib/actions'; 
import { getSchoolConfig, getStudentById, getAllClaims, getAllStudents } from '@/lib/data';
import type { PhoneClaim, Student } from '@/lib/definitions';
import { sendSms } from '@/lib/actions';

const INVOICES_FILE_PATH = path.join(process.cwd(), 'src', 'data', 'invoices.json');

async function readInvoicesFile(): Promise<Invoice[]> {
  try {
    await fs.access(INVOICES_FILE_PATH);
    const fileContent = await fs.readFile(INVOICES_FILE_PATH, 'utf-8');
    return fileContent ? JSON.parse(fileContent) : [];
  } catch (error) {
    return [];
  }
}

async function writeInvoicesFile(invoices: Invoice[]) {
  await fs.writeFile(INVOICES_FILE_PATH, JSON.stringify(invoices, null, 2));
}

export async function POST(req: Request) {
  try {
    const { 
        phone, // Guardian's phone for SMS
        otp, 
        invoiceId, 
        purchaseType, 
        bundleName, 
        bundlePrice,
        bundleCredits, 
        studentName, // Directly passed for non-admin flow
    } = await req.json();

    if (!phone || !otp || !invoiceId || !purchaseType || !bundlePrice) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    const adminPhoneNumber = '0536282694';
    const otpResult = await verifyOtp(adminPhoneNumber, otp);
    if (!otpResult.success) {
      return NextResponse.json({ error: 'Invalid activation code.' }, { status: 401 });
    }

    const invoices = await readInvoicesFile();
    const invoiceIndex = invoices.findIndex(inv => inv.id === invoiceId);

    if (invoiceIndex === -1) {
      return NextResponse.json({ error: 'Invoice not found' }, { status: 404 });
    }

    const currentInvoice = invoices[invoiceIndex];
    if (currentInvoice.status === 'PAID') {
        return NextResponse.json({ success: true, message: 'Payment was already confirmed.' });
    }
    currentInvoice.status = 'PAID';
    currentInvoice.updatedAt = new Date().toISOString();
    await writeInvoicesFile(invoices);
    
    // --- Start of SMS Confirmation Logic ---
    const allStudents = await getAllStudents();
    const schoolConfig = await getSchoolConfig();
    let student: Student | undefined;
    let guardianName = "Guardian"; // Default name
    let guardianPhone = phone; // Phone is now passed directly

    if (purchaseType === 'fee') {
        // Non-admin flow: we get studentName and guardianPhone directly.
        student = allStudents.find(s => s.studentName === studentName);
        const allClaims = await getAllClaims();
        // We can still try to find the original claim to get a more accurate guardian name if available
        const originalClaim = allClaims.find(c => c.invoiceNumber === bundleCredits);
        if (originalClaim) {
            guardianName = originalClaim.guardianName;
        }

    } else {
        // Admin flow: bundleCredits is the studentId.
        student = allStudents.find(s => s.id === bundleCredits);
        if (student) {
           const allClaims = await getAllClaims();
           const recentClaimForStudent = allClaims.find(c => c.studentName === student!.studentName);
           if(recentClaimForStudent) {
              guardianName = recentClaimForStudent.guardianName;
              guardianPhone = recentClaimForStudent.guardianPhone;
           }
        }
    }
    
    if (student) {
        const amountPaid = parseFloat(bundlePrice);
        const newBalance = student.balance - amountPaid;
        
        const personalizedMessage = `Dear ${guardianName}, we have received a payment of GHS ${amountPaid.toFixed(2)} for ${student.studentName}. The new balance is GHS ${newBalance.toFixed(2)}. Thank you.`;

        await sendSms(
          [{
              destination: guardianPhone,
              message: personalizedMessage,
              msgid: `conf-${currentInvoice.id.slice(0, 8)}`
          }],
          schoolConfig.senderId
        );
    }
    // --- End of SMS Confirmation Logic ---
    
    return NextResponse.json({ success: true, message: 'Purchase finalized successfully' });

  } catch (error) {
    console.error('Failed to finalize purchase:', error);
    const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
    return NextResponse.json({ error: 'Failed to finalize purchase', details: errorMessage }, { status: 500 });
  }
}
