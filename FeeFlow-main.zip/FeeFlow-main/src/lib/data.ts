

"use server";

import type { Student, SchoolConfig, PhoneClaim, InvoiceGenerationClaim, AdminUser } from './definitions';
import fs from 'fs/promises';
import path from 'path';
import { PlaceHolderImages } from './placeholder-images';

const SPREADSHEET_ID = '1WHkw5YaVbnHjWD2nwTcYnQfIYV7PxascjEzY7FqL4Ew';
const CLAIMS_FILE_PATH = path.join(process.cwd(), 'src', 'data', 'claims.json');

// Helper function to ensure the claims file exists and read its content
async function readClaimsFile(): Promise<PhoneClaim[]> {
  try {
    // Check if file exists, if not, create it with an empty array.
    await fs.access(CLAIMS_FILE_PATH);
  } catch (error) {
    await fs.writeFile(CLAIMS_FILE_PATH, JSON.stringify([], null, 2));
    return [];
  }

  const fileContent = await fs.readFile(CLAIMS_FILE_PATH, 'utf-8');
  if (fileContent) {
    try {
      return JSON.parse(fileContent);
    } catch (e) {
      console.error("Error parsing claims.json, returning empty array", e);
      return [];
    }
  }
  return [];
}


// Helper function to parse CSV text into an array of objects
function csvToObjects(csv: string): any[] {
  const lines = csv.trim().split('\n');
  if (lines.length < 2) return [];

  const headers = lines[0].split(',').map(h => h.replace(/"/g, '').trim());
  const objects = [];

  for (let i = 1; i < lines.length; i++) {
    const obj: { [key: string]: string } = {};
    // Split by comma only if it's not enclosed in quotes
    const currentline = lines[i].split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/); 

    for (let j = 0; j < headers.length; j++) {
      const header = headers[j];
      let value = (currentline[j] || '').trim();
      // Remove quotes from start and end if they exist
      if (value.startsWith('"') && value.endsWith('"')) {
        value = value.substring(1, value.length - 1);
      }
      obj[header] = value;
    }
    objects.push(obj);
  }
  return objects;
}


async function getSenderIdFromTemplateSheet(): Promise<string> {
    const defaultSenderId = 'CHARIOT EDU';
    try {
        const url = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/gviz/tq?tqx=out:csv&sheet=Template`;
        const response = await fetch(url, { next: { revalidate: 60 } });
        if (!response.ok) {
            console.warn(`Could not fetch Template sheet, using default Sender ID. Status: ${response.statusText}`);
            return defaultSenderId;
        }
        const csvText = await response.text();
        const templateData = csvToObjects(csvText);

        // Assuming the Sender ID is in the first row of the "Sender ID" column
        if (templateData.length > 0 && templateData[0]['Sender ID']) {
            return templateData[0]['Sender ID'];
        }
        
        console.warn("Sender ID not found in Template sheet, using default.");
        return defaultSenderId;
    } catch (error) {
        console.error("Error fetching Sender ID from Template sheet:", error);
        return defaultSenderId;
    }
}


export async function getSchoolConfig(): Promise<SchoolConfig> {
  try {
    const configUrl = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/gviz/tq?tqx=out:csv&sheet=Config`;
    
    const [configResponse, senderId] = await Promise.all([
      fetch(configUrl, { next: { revalidate: 60 } }),
      getSenderIdFromTemplateSheet()
    ]);

    if (!configResponse.ok) {
      throw new Error(`Failed to fetch config sheet: ${configResponse.statusText}`);
    }
    const csvText = await configResponse.text();
    const configData = csvToObjects(csvText);
    
    if (configData.length === 0) {
      throw new Error("Config sheet is empty or has no data rows.");
    }
    
    const configRow = configData[0];
    if (!configRow) {
      throw new Error("Could not find a valid config row in the 'Config' sheet.");
    }
    
    const logo = PlaceHolderImages.find(img => img.id === 'school-logo');

    return {
        schoolName: configRow['School Name'] || 'Chariot Educational Complex',
        address: configRow['Address'] || 'P.O.Box TA Old-Tafo',
        momoNumber: configRow['Momo number'] || '',
        dueDate: configRow['Due Date'] || '',
        invoicePrefix: configRow['Invoice number'] || 'CEC-INV',
        senderId: senderId, // Use senderId from Template sheet
        logoUrl: logo?.imageUrl || '',
    };
  } catch (error) {
    console.error("Error fetching school config from Google Sheet:", error);
    const logo = PlaceHolderImages.find(img => img.id === 'school-logo');
    // Return a default/error state
    return {
        schoolName: "Chariot Educational Complex",
        address: "P.O.Box TA Old-Tafo",
        momoNumber: "23356282694 - David Amankwaah",
        dueDate: "30/10/2025",
        invoicePrefix: "CEC-INV",
        senderId: "CHARIOT EDU", // Fallback senderId
        logoUrl: logo?.imageUrl || "",
    };
  }
}

// Helper function to safely parse a currency string to a float
const parseCurrency = (value: string | undefined): number => {
    if (!value) return 0;
    const cleanedValue = value.replace(/[^0-9.-]+/g, "");
    const number = parseFloat(cleanedValue);
    return isNaN(number) ? 0 : number;
};


export async function getAllStudents(): Promise<Student[]> {
    try {
        const url = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/gviz/tq?tqx=out:csv&sheet=Metadata`;
        const response = await fetch(url, { next: { revalidate: 60 } });
         if (!response.ok) {
            throw new Error(`Failed to fetch students sheet: ${response.statusText}`);
        }
        const csvText = await response.text();
        const studentData = csvToObjects(csvText);

        if (studentData.length === 0) return [];
        
        const students = studentData.map((s, index) => {
            // Use 'Total Balance' from the sheet as the source of truth for the balance.
            const balance = parseCurrency(s['Total Balance']);
            
            // Fee components
            const arrears = parseCurrency(s['ARREAS']);
            const books = parseCurrency(s['BOOKS Fees']);
            const fees = parseCurrency(s['School Fees AMOUNT']);
            
            // Payment components
            const initialAmountPaid = parseCurrency(s['INTIAL AMOUNT PAID']);
            const payment = parseCurrency(s['PAYMENT']);
            const booksFeePayment = parseCurrency(s['BOOKS Fees Payment']);
            
            const schoolFeesPaid = initialAmountPaid + payment;
            const totalPaid = schoolFeesPaid + booksFeePayment;

            let gender: Student['gender'] = 'Other';
            const genderVal = s['GENDER']?.trim();
            if (genderVal === 'Male') {
                gender = 'Male';
            } else if (genderVal === 'Female') {
                gender = 'Female';
            }
            
            const student: Student = {
                id: s['No.'] || `${index}`,
                studentName: s['NAME'] || '',
                class: s['GRADE'] || '',
                studentType: s['Student Type'] || '',
                balance: balance,
                arrears: arrears,
                books: books,
                fees: fees,
                amountPaid: totalPaid,
                schoolFeesPaid: schoolFeesPaid,
                booksFeePaid: booksFeePayment,
                gender: gender,
                guardianName: s['Guardian Name'] || '',
                guardianPhone: s['Guardian Phone'] || '',
            };
            return student;
        }).filter(s => s.studentName && s.class);

        return students;

    } catch(error) {
        console.error("Error fetching students from Google Sheet:", error);
        return [];
    }
}


export async function getClasses(): Promise<string[]> {
  const students = await getAllStudents();
  if (!students || students.length === 0) {
    console.log("No students found, returning empty class list.");
    return [];
  }
  const classes = [...new Set(students.map(s => s.class))];
  return classes.filter(c => c);
}

export async function getStudentsByClass(className: string): Promise<Student[]> {
  const allStudents = await getAllStudents();
  const filteredStudents = allStudents.filter(s => s.class === className);
  return filteredStudents;
}

export async function getStudentById(studentId: string): Promise<Student | undefined> {
  const allStudents = await getAllStudents();
  const student = allStudents.find(s => s.id === studentId);
  return student;
}

export async function saveClaim(data: Omit<PhoneClaim, 'timestamp'>): Promise<{ success: boolean; message?: string }> {
  const claim: PhoneClaim = {
    ...data,
    timestamp: new Date().toISOString(),
  };

  try {
    const claims = await readClaimsFile();
    claims.push(claim);
    await fs.writeFile(CLAIMS_FILE_PATH, JSON.stringify(claims, null, 2));

    console.log("Successfully saved claim to claims.json:", claim);
    return { success: true };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Error saving to claims.json:", errorMessage, error);
    return { success: false, message: `Could not save claim data. Reason: ${errorMessage}` };
  }
}

export async function deleteClaim(invoiceNumber: string): Promise<{ success: boolean; message?: string }> {
  try {
    const claims = await readClaimsFile();
    const updatedClaims = claims.filter(claim => claim.invoiceNumber !== invoiceNumber);

    if (claims.length === updatedClaims.length) {
      return { success: false, message: "Claim with that invoice number not found." };
    }

    await fs.writeFile(CLAIMS_FILE_PATH, JSON.stringify(updatedClaims, null, 2));
    
    console.log(`Successfully deleted claim with invoice number: ${invoiceNumber}`);
    return { success: true };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Error deleting claim from claims.json:", errorMessage, error);
    return { success: false, message: `Could not delete claim data. Reason: ${errorMessage}` };
  }
}

export async function deleteMultipleClaims(invoiceNumbers: string[]): Promise<{ success: boolean; message?: string }> {
  try {
    let claims = await readClaimsFile();
    const initialLength = claims.length;
    claims = claims.filter(claim => !invoiceNumbers.includes(claim.invoiceNumber));

    if (claims.length === initialLength) {
      return { success: false, message: "No matching claims found to delete." };
    }

    await fs.writeFile(CLAIMS_FILE_PATH, JSON.stringify(claims, null, 2));
    
    console.log(`Successfully deleted ${initialLength - claims.length} claims.`);
    return { success: true };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Error deleting multiple claims from claims.json:", errorMessage, error);
    return { success: false, message: `Could not delete claims. Reason: ${errorMessage}` };
  }
}

export async function getClaimsForInvoiceGeneration(): Promise<InvoiceGenerationClaim[]> {
  try {
    const claims = await readClaimsFile();
    // Sort claims by timestamp to get the latest ones for invoice number generation
    const sortedClaims = claims.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    return sortedClaims.map(c => ({ invoiceNumber: c.invoiceNumber })).filter(c => c.invoiceNumber);
  } catch (error) {
    console.error("Error fetching claims from claims.json:", error);
    return [];
  }
}

export async function getAllClaims(): Promise<PhoneClaim[]> {
    try {
        const claims = await readClaimsFile();
        // Sort by timestamp descending so newest claims are first
        return claims.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    } catch (error) {
        console.error("Error fetching all claims from claims.json:", error);
        return [];
    }
}

export async function getAdminUsers(): Promise<AdminUser[]> {
    try {
        const url = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/gviz/tq?tqx=out:csv&sheet=Admin`;
        const response = await fetch(url, { next: { revalidate: 60 } });
         if (!response.ok) {
            throw new Error(`Failed to fetch Admin sheet: ${response.statusText}`);
        }
        const csvText = await response.text();
        const adminData = csvToObjects(csvText);

        if (adminData.length === 0) return [];
        
        const admins: AdminUser[] = adminData.map(a => ({
            username: a['Username'] || '',
            password: a['Password'] || '',
            role: a['Role'] || '',
        })).filter(a => a.username);

        return admins;

    } catch(error) {
        console.error("Error fetching admins from Google Sheet:", error);
        return [];
    }
}

    
