
export type Student = {
  id: string;
  studentName: string;
  class: string;
  studentType: string;
  fees: number;
  arrears: number;
  amountPaid: number; // Total amount paid (school fees + books fee)
  schoolFeesPaid: number; // Only 'INITIAL AMOUNT PAID' + 'PAYMENT'
  booksFeePaid: number; // Only 'BOOKS Fees Payment'
  balance: number;
  books: number;
  gender: 'Male' | 'Female' | 'Other';
  guardianName?: string;
  guardianPhone?: string;
};

export type SchoolConfig = {
  schoolName: string;
  address: string;
  momoNumber: string;
  dueDate: string;
  invoicePrefix: string;
  senderId: string;
  logoUrl: string;
};

export type PhoneClaim = {
  guardianName: string;
  guardianPhone: string;
  relationship: string;
  studentName: string;
  class: string;
  totalFeesBalance: number;
  dueDate: string;
  invoiceNumber: string;
  timestamp: string;
};

// Kept for invoice generation logic, but not for saving.
export type InvoiceGenerationClaim = {
  invoiceNumber: string;
};

export type AdminUser = {
  username: string;
  password?: string;
  role: string;
}
