
"use server";

const FROG_API_URL = "https://frogapi.wigal.com.gh/api/v3";
const SENDER_ID = "CampusFlow";
const API_KEY = "$2y$10$6oYYcjc6Ge3/W.P.1Yqk6eHBs0ERVFR6IaBQ2qpYGBnMYp28B3uPe";
const USERNAME = "amanvid";

export async function generateVerificationCode(phone: string): Promise<{ status: string; message: string }> {
  try {
    const response = await fetch(`${FROG_API_URL}/sms/otp/generate`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "API-KEY": API_KEY,
        "USERNAME": USERNAME,
      },
      body: JSON.stringify({
        number: phone,
        expiry: 5,
        length: 6,
        messagetemplate: `Your ${SENDER_ID} verification code is: %OTPCODE%. It expires in %EXPIRY% minutes.`,
        type: "NUMERIC",
        senderid: SENDER_ID,
      }),
    });
    return await response.json();
  } catch (error) {
    console.error("Error in generateVerificationCode:", error);
    return { status: "FAILED", message: "An unexpected error occurred." };
  }
}

export async function verifyOtp(phone: string, otp: string): Promise<{ status: string; message: string }> {
  try {
    const response = await fetch(`${FROG_API_URL}/sms/otp/verify`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "API-KEY": API_KEY,
            "USERNAME": USERNAME,
        },
        body: JSON.stringify({
            otpcode: otp,
            number: phone,
        }),
    });
    return await response.json();
  } catch (error) {
    console.error("Error in verifyOtp:", error);
    return { status: "FAILED", message: "An unexpected error occurred." };
  }
}

export async function generateActivationCode(phone: string): Promise<{ status: string; message: string }> {
    try {
      const response = await fetch(`${FROG_API_URL}/sms/otp/generate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          "API-KEY": API_KEY,
          "USERNAME": USERNAME,
        },
        body: JSON.stringify({
          number: phone,
          expiry: 20, // Longer expiry for activation
          length: 8, // 8-digit code for higher security
          messagetemplate: `Your ${SENDER_ID} activation code is: %OTPCODE%. It expires in %EXPIRY% minutes.`,
          type: 'ALPHANUMERIC',
          senderid: SENDER_ID,
        }),
      });
      return await response.json();
    } catch (error) {
        console.error('Error generating activation code:', error);
        return { status: 'FAILED', message: 'An unexpected error occurred.' };
    }
}


export async function sendSms(recipients: string[], message: string, systemId?: string): Promise<{ success: boolean; error?: string }> {
  try {
    const response = await fetch(`${FROG_API_URL}/sms/send`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "API-KEY": API_KEY,
        "USERNAME": USERNAME,
      },
      body: JSON.stringify({
        recipient: recipients,
        message: message,
        senderid: systemId || SENDER_ID,
      }),
    });
    const data = await response.json();
    if (data.status === 'SUCCESS') {
      return { success: true };
    }
    return { success: false, error: data.message || 'Failed to send SMS' };
  } catch (error) {
    console.error('Error sending SMS:', error);
    return { success: false, error: 'An unexpected error occurred.' };
  }
}
